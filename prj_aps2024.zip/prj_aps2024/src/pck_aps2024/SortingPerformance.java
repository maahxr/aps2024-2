package pck_aps2024;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class SortingPerformance {

    // Algoritmo Bubble Sort
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // Algoritmo Merge Sort
    public static void mergeSort(int[] arr) {
        if (arr.length > 1) {
            int mid = arr.length / 2;
            int[] left = Arrays.copyOfRange(arr, 0, mid);
            int[] right = Arrays.copyOfRange(arr, mid, arr.length);

            mergeSort(left);
            mergeSort(right);

            merge(arr, left, right);
        }
    }

    private static void merge(int[] arr, int[] left, int[] right) {
        int i = 0, j = 0, k = 0;
        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                arr[k++] = left[i++];
            } else {
                arr[k++] = right[j++];
            }
        }
        while (i < left.length) {
            arr[k++] = left[i++];
        }
        while (j < right.length) {
            arr[k++] = right[j++];
        }
    }

    // Algoritmo Quick Sort
    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(arr, low, high);
            quickSort(arr, low, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, high);
        }
    }

    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }

    // Carregar dados externos de um arquivo
    public static int[] loadDataFromFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            int[] data = reader.lines().mapToInt(Integer::parseInt).toArray();
            System.out.println("Quantidade de valores no arquivo externo: " + data.length);
            return data;
        } catch (IOException e) {
            System.out.println("Erro ao carregar o arquivo: " + e.getMessage());
            return new int[0];
        }
    }

    // Gerar dados aleatórios para teste
    public static int[] generateRandomData(int size) {
        Random rand = new Random();
        int[] data = new int[size];
        for (int i = 0; i < size; i++) {
            data[i] = rand.nextInt(10000); // Valores aleatórios entre 0 e 9999
        }
        return data;
    }

    // Método para medir o tempo de execução dos algoritmos de ordenação
    public static void measureSortingPerformance(int[] data, String algorithmName) {
        long startTime = System.nanoTime();

        switch (algorithmName) {
            case "Bubble Sort":
                bubbleSort(data);
                break;
            case "Merge Sort":
                mergeSort(data);
                break;
            case "Quick Sort":
                quickSort(data, 0, data.length - 1);
                break;
        }

        long endTime = System.nanoTime();
        double durationInSeconds = (endTime - startTime) / 1_000_000_000.0;
        System.out.printf("%s: %.6f segundos%n", algorithmName, durationInSeconds);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Carregar dados externos
        int[] externalData = loadDataFromFile("dados_externos.txt");
        if (externalData.length == 0) {
            System.out.println("Dados externos não encontrados, usando dados aleatórios como fallback.");
            externalData = generateRandomData(1000); // Fallback com 1000 valores aleatórios
        }

        // Solicitar ao usuário a quantidade de dados internos a serem gerados
        System.out.print("Digite a quantidade de valores internos aleatórios a serem gerados: ");
        int quantidadeInterna = scanner.nextInt();
        int[] internalData = generateRandomData(quantidadeInterna);

        // Guardar os dados originais para exibir o "antes e depois" posteriormente
        int[] bubbleExternalData = Arrays.copyOf(externalData, externalData.length);
        int[] mergeExternalData = Arrays.copyOf(externalData, externalData.length);
        int[] quickExternalData = Arrays.copyOf(externalData, externalData.length);

        int[] bubbleInternalData = Arrays.copyOf(internalData, internalData.length);
        int[] mergeInternalData = Arrays.copyOf(internalData, internalData.length);
        int[] quickInternalData = Arrays.copyOf(internalData, internalData.length);

        System.out.println("\nComparando performance com dados externos:");
        measureSortingPerformance(bubbleExternalData, "Bubble Sort");
        measureSortingPerformance(mergeExternalData, "Merge Sort");
        measureSortingPerformance(quickExternalData, "Quick Sort");

        System.out.println("\nComparando performance com dados internos:");
        measureSortingPerformance(bubbleInternalData, "Bubble Sort");
        measureSortingPerformance(mergeInternalData, "Merge Sort");
        measureSortingPerformance(quickInternalData, "Quick Sort");

        // Perguntar ao usuário se deseja ver o antes e depois
        System.out.print("\nDeseja ver o antes e depois da ordenação para todos os métodos? (SIM/NAO): ");
        String resposta = scanner.next().trim().toUpperCase();

        if (resposta.equals("SIM")) {
            System.out.println("\nDados Externos - Antes da ordenação:");
            System.out.println("Bubble Sort: " + Arrays.toString(externalData));
            System.out.println("Merge Sort: " + Arrays.toString(externalData));
            System.out.println("Quick Sort: " + Arrays.toString(externalData));

            System.out.println("\nDados Externos - Depois da ordenação:");
            System.out.println("Bubble Sort: " + Arrays.toString(bubbleExternalData));
            System.out.println("Merge Sort: " + Arrays.toString(mergeExternalData));
            System.out.println("Quick Sort: " + Arrays.toString(quickExternalData));

            System.out.println("\nDados Internos - Antes da ordenação:");
            System.out.println("Bubble Sort: " + Arrays.toString(internalData));
            System.out.println("Merge Sort: " + Arrays.toString(internalData));
            System.out.println("Quick Sort: " + Arrays.toString(internalData));

            System.out.println("\nDados Internos - Depois da ordenação:");
            System.out.println("Bubble Sort: " + Arrays.toString(bubbleInternalData));
            System.out.println("Merge Sort: " + Arrays.toString(mergeInternalData));
            System.out.println("Quick Sort: " + Arrays.toString(quickInternalData));
        }

        scanner.close();
    }
}
